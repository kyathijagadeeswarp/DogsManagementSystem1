package maps;

import java.util.HashMap;
import java.util.Map;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public class StudentMap {
	private Map<Integer, Student> studentMap;
	public StudentMap() {
		studentMap = new HashMap<>();
	}
	public void insertStudentDetails(Student s) {
		studentMap.put(s.getSID(), s);
	}
	public void printStudentDetails() {
		for (Map.Entry<Integer, Student> ety : studentMap.entrySet()) {
			int sID = ety.getKey();
			Student student = ety.getValue();
			
			System.out.println("**************************");
			System.out.println("Student ID: " + sID);
			System.out.println("name: " + student.getName());
			System.out.println("branch: " + student.getBranch());
			System.out.println("courseRegistered: " + student.getRegisteredCourse());
			System.out.println("school: " + student.getSchool());
		}
	}

	public void updateStudentCourse(int sID, String course) {
		
		if (studentMap.containsKey(sID)) {
			Student std = studentMap.get(sID);
			std.setRegisteredCourse(course);
			studentMap.put(sID, std);
			
		} 
		else {
			System.out.println("Student ID: " + sID + " not found in the map.");
		}
	}

	public void deleteStudent(int sID) {
		if (studentMap.containsKey(sID)) {
			studentMap.remove(sID);
			
		} 
		else {
			System.out.println("Student ID: " + sID + " not found in the map.");
		}
	}
}
