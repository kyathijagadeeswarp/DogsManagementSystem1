package maps;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public class Student {
	
	private int sID;
	private String name;
	private String branch;
	private String registeredCourse;
	private String school;

	public Student(int sID, String name, String branch, String registeredCourse, String school) {
		this.sID = sID;
		this.name = name;
		this.branch = branch;
		this.registeredCourse = registeredCourse;
		this.school = school;
	}

	public int getSID() {
		return sID;
	}

	public String getName() {
		return name;
	}

	public String getBranch() {
		return branch;
	}

	public String getRegisteredCourse() {
		return registeredCourse;
	}

	public String getSchool() {
		return school;
	}

	public void setRegisteredCourse(String registeredCourse) {
		this.registeredCourse = registeredCourse;
	}
}
