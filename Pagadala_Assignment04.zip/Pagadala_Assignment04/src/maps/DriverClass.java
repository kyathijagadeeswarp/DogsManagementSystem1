package maps;

import java.util.Scanner;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public class DriverClass {
	public static void main(String[] args) {
		Scanner scnn = new Scanner(System.in);
		StudentMap stdMp = new StudentMap();
		for (int i = 0; i < 5; i++) {
			System.out.print("Enter student id: ");
			
			int sID = scnn.nextInt();
			scnn.nextLine();
			System.out.print("Enter student name: ");
			
			String name = scnn.nextLine();
			System.out.print("Enter student branch: ");
			
			String branch = scnn.nextLine();
			System.out.print("Enter student registered course: ");
			
			String registeredCourse = scnn.nextLine();
			System.out.print("Enter student's school: ");
			
			String school = scnn.nextLine();
			Student std = new Student(sID, name, branch, registeredCourse, school);
			stdMp.insertStudentDetails(std);
		}
		System.out.println("Student Details are: ");
		
		stdMp.printStudentDetails();
		System.out.print("Enter any student id to update: ");
		
		int updId = scnn.nextInt();
		scnn.nextLine(); 
		System.out.print("Enter the new registered course: ");
		
		String nwCr = scnn.nextLine();
		stdMp.updateStudentCourse(updId, nwCr);
		System.out.println("After updating student details are: ");
		
		stdMp.printStudentDetails();
		System.out.print("Enter any student id to delete: ");
		
		int dltId = scnn.nextInt();
		stdMp.deleteStudent(dltId);
		System.out.println("After removing student details are: ");	
		stdMp.printStudentDetails();
		scnn.close();
	}
}
