package sets;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public interface TreeSetInterface {
	void add(int element);
	void remove(int element);
	int size() ;
	boolean contains(int element);
}





