package sets;

import java.util.Scanner;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public class DriverClass {
	public static void main(String[] args) {
		Scanner scnn = new Scanner(System.in);
		MyTreeSet myTreeSet = new MyTreeSet();
		System.out.print("Enter the size of the tree set: ");
		
		int size = scnn.nextInt();
		int cce;
		do {
			System.out.println("Choose the options");
			System.out.println("1.insert 2.delete 3.check the presence 4.print 5.Exit");
			
			cce = scnn.nextInt();
			switch (cce) {
			
			case 1:
				System.out.print("Enter the number to add to the list ");
				int Adnu = scnn.nextInt();
				myTreeSet.add(Adnu);
				System.out.println(Adnu + " is added to the set");
				break;
				
			case 2:
				System.out.print("Enter the number to delete ");
				int Denu = scnn.nextInt();
				if (myTreeSet.contains(Denu)) {
					myTreeSet.remove(Denu);
					System.out.println(Denu + " has been deleted successfully");
				} else {
					System.out.println(Denu + " is not present in the set");
				}
				break;
				
			case 3:
				System.out.print("Enter the number to check the presence ");
				int Chnu = scnn.nextInt();
				if (myTreeSet.contains(Chnu)) {
					System.out.println(Chnu + " is present in the set");
				} else {
					System.out.println(Chnu + " is not present in the set");
				}
				break;
				
			case 4:
				System.out.print("Elements in the tree set are: ");
				for (int nmb : myTreeSet) {
					System.out.print(nmb + " ");
				}
				System.out.println();
				break;
				
			case 5:
				break;
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		} 
		while (cce != 5);
		scnn.close();
	}
}
