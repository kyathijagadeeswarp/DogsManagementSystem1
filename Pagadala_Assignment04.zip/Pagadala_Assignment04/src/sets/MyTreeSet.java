package sets;

import java.util.ArrayList;
import java.util.Iterator;

/**
* S560448 Kyathi Jagadeeswar Pagadala
*/

public class MyTreeSet implements TreeSetInterface, Iterable<Integer> {
	private ArrayList<Integer> aList;
	public MyTreeSet() {
		aList = new ArrayList<>();
	}
	@Override
	public void add(int element) {
		if (!aList.contains(element)) {
			aList.add(element);
			sortArrayList();
		}
	}
	@Override
	public void remove(int element) {
		aList.remove(Integer.valueOf(element));
	}
	@Override
	public int size() {
		return aList.size();
	}
	@Override
	public boolean contains(int element) {
		return aList.contains(element);
	}
	@Override
	public Iterator<Integer> iterator() {
		return aList.iterator();
	}

	private void sortArrayList() {
		int f = aList.size();
		for (int g = 0; g < f - 1; g++) {
			for (int h = 0; h < f - g - 1; h++) {
				if (aList.get(h) > aList.get(h + 1)) {
					int tm1 = aList.get(h);
					aList.set(h, aList.get(h + 1));
					aList.set(h + 1, tm1);
				}
			}
		}
	}
}







